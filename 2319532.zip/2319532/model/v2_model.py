from v1_model import *
import pandas as pd
import numpy as np
import math
import sys
from scipy.stats import pearsonr


def data_perprocess(path= './collect.csv'):

    # load the data from csv file and wash them
    file = pd.read_csv(path)
    global name_list
    name_list = list(file['Locations'])
    annual_light = list(file['ANL'].astype(int))
    annual_light = positivization(annual_light, mode='1')

    airpollution_list = list(file['PM'].astype(float))
    airpollution_list = positivization(airpollution_list)

    population_list = list(file['POP'].astype(int))
    population_list = positivization(population_list, mode='0', toOne='minmax')
    

    GDP_list = list(file['GDP'].astype(str))
    new = []
    for i in GDP_list:
        i = i.replace(',','')
        new.append(int(i))
    GDP_list = positivization(new)

    temp_list = list(file['TMP'].astype(str))
    low_list, high_list = [], []
    for tem_tuple in temp_list:
        tem_tuple = tem_tuple.replace('（','')
        tem_tuple = tem_tuple.replace('）','')
        tem_tuple = tem_tuple.split('，')
        low_list.append(int(tem_tuple[0]))
        high_list.append(int(tem_tuple[1]))   
    low_list = positivization(low_list, mode='3', ifStd=False)
    high_list = positivization(high_list, mode='3', ifStd=False)
    new = []
    for k in range(len(low_list)):
        new.append(low_list[k]+high_list[k])
    temp_list = positivization(new)

    rain_list = list(file['ARF'].astype(int))
    rain_list = positivization(rain_list, mode='2', best_cir= int(sum(rain_list)/len(rain_list)))

    electric_list = list(file['REC'].astype(int))
    electric_list = positivization(electric_list)

    skyglow_list = list(file['skyglow'].astype(int))
    skyglow_list = positivization(skyglow_list)

    UL_intensity_list = list(file['ULI'].astype(float))
    UL_intensity_list = positivization(UL_intensity_list)

    std_list = list(file['STD'].astype(float))
    std_list = positivization(std_list)

    clutter_list = list(file['CLI'].astype(float))
    clutter_list = positivization(clutter_list)

    knum_list = list(file['CNB'].astype(int))
    knum_list = positivization(knum_list)

    Unit_light_intensity_list = dataCorrection(
        target= UL_intensity_list,
        input= [annual_light, airpollution_list, temp_list, rain_list, skyglow_list]
    )

    Development_list = dataCorrection(
        target= GDP_list,
        input= [population_list, electric_list]
    )

    Clutter_list = dataCorrection(
        target= clutter_list,
        input=[std_list, knum_list]
    )

    return Unit_light_intensity_list, Development_list, Clutter_list

    
def dataCorrection(target, input, mode = 'normalize'):
    
    # solving for the corrected data series
    output = target.copy()
    for input_sequence in input:
        pccs = pearsonr(target, input_sequence)
        alpha = pccs[0]
        output = list(map(lambda x :x[0]+x[1]*alpha ,zip(output, input_sequence)))
    
    # define if it is necessary to normalize the data (data washing button)
    if mode == 'normalize':
        output = positivization(output)
    return output


if __name__ == '__main__':
        
    all = np.array(data_perprocess('./collect.csv'))
    weight = distanceCal(all, aug_pos=-1)
    dis_weight = TOPSIS(all, weight)

    #  np.save('weight.npy', np.array(dis_weight))

    map2level(all, dis_weight, name_list, save_path='./score.csv')
    
    